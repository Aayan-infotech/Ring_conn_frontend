import React, { useState } from 'react';
import './ProductDetails.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { FaShoppingCart } from 'react-icons/fa';

const imageOptions = [
  '/images/shoe.jpg',
  '/images/shoe2.jpg',
  '/images/shoe3.jpg',
  '/images/shoe4.jpg'
];

const sizeOptions = [38, 40, 42];

export default function ProductDetails() {
  const [selectedImage, setSelectedImage] = useState(imageOptions[0]);
  const [quantity, setQuantity] = useState(2);
  const [selectedSize, setSelectedSize] = useState(sizeOptions[0]);

  const handleImageClick = (img) => setSelectedImage(img);

  const handleQuantityChange = (type) => {
    if (type === 'decrease' && quantity > 1) setQuantity(quantity - 1);
    if (type === 'increase' && quantity < 10) setQuantity(quantity + 1);
  };

  const handleSizeSelect = (size) => setSelectedSize(size);

  const handleAddToCart = () => {
    alert(`Added ${quantity} pair(s) of size ${selectedSize} to cart.`);
  };

  return (
    <div className="product-details container py-5">
      <div className="row g-5">
        {/* Left: Image Preview */}
        <div className="col-md-6">
          <div className="main-image-wrapper mb-3">
            <img src={selectedImage} alt="Selected" className="img-fluid rounded shadow product-image" />
          </div>
          <div className="d-flex justify-content-between thumbnail-images">
            {imageOptions.map((img, i) => (
              <img
                key={i}
                src={img}
                onClick={() => handleImageClick(img)}
                className={`img-thumbnail thumb ${selectedImage === img ? 'selected' : ''}`}
                alt={`thumb-${i}`}
              />
            ))}
          </div>
        </div>

        {/* Right: Product Info */}
        <div className="col-md-6">
          <h2 className="fw-bold display-6 mb-2">GLAMOR SHOES</h2>
          <p className="text-muted mb-2">SKU: <span className="fw-semibold">#0005</span> | <span className="text-success">26 ITEMS</span></p>
          <p className="text-secondary fs-6 mb-4">
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Lorem ipsum dolor sit amet consectetur adipisicing elit.
          </p>

          <div className="product-option mb-4">
            <p className="option-label">COLOR:</p>
            <div className="d-flex gap-3">
              {imageOptions.slice(0, 3).map((img, i) => (
                <img
                  key={i}
                  src={img}
                  onClick={() => handleImageClick(img)}
                  className={`img-thumbnail color-option ${selectedImage === img ? 'selected' : ''}`}
                  alt={`color-${i}`}
                />
              ))}
            </div>
          </div>

          <div className="product-option mb-4">
            <p className="option-label">SIZE:</p>
            <div className="btn-group" role="group">
              {sizeOptions.map((size) => (
                <button
                  key={size}
                  onClick={() => handleSizeSelect(size)}
                  className={`btn btn-outline-primary ${selectedSize === size ? 'active' : ''}`}
                >
                  {size}
                </button>
              ))}
            </div>
            <span className="ms-3 text-decoration-underline text-primary size-guide">Size Guide</span>
          </div>

          <div className="product-option mb-4">
            <p className="option-label">MATERIAL:</p>
            <button className="btn btn-outline-dark btn-sm">SYNTHETICS</button>
          </div>

          <div className="product-option mb-4">
            <p className="option-label">QTY:</p>
            <div className="input-group quantity-control">
              <button className="btn btn-outline-secondary" onClick={() => handleQuantityChange('decrease')}>-</button>
              <input type="text" value={quantity} className="form-control text-center" readOnly />
              <button className="btn btn-outline-secondary" onClick={() => handleQuantityChange('increase')}>+</button>
            </div>
            <small className="text-muted d-block">Max 10 items</small>
          </div>

          <h3 className="text-primary fw-bold price-display">
            $180.00 <span className="text-decoration-line-through text-muted fs-5">$210.00</span>
          </h3>

          <button onClick={handleAddToCart} className="btn btn-info text-white w-100 d-flex align-items-center justify-content-center gap-2 mt-4 shadow">
            <FaShoppingCart /> ADD TO CART
          </button>

          <p className="mt-4 fw-semibold text-success checkout-note">GUARANTEED SAFE CHECKOUT</p>
        </div>
      </div>
    </div>
  );
}
